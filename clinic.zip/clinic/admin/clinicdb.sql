-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2020 at 01:22 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinicdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `a_name` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `clinic_name` varchar(30) NOT NULL,
  `password1` varchar(50) NOT NULL,
  `Register_date` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `a_name`, `Username`, `address`, `phone_number`, `clinic_name`, `password1`, `Register_date`) VALUES
(1, 'admin', 'admin', 'Kwerekwe', '0778277832', 'Kibweni', '202cb962ac59075b964b07152d234b70', '8/13/2020'),
(2, 'Test', 'Admin2', '1qqqq', '123456', 'qwass', '25f9e794323b453885f5181f1b624d0b', '2020-08-13 05:40:15');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_record`
--

CREATE TABLE `clinic_record` (
  `clinic_id` int(11) NOT NULL,
  `partient_id` int(11) NOT NULL,
  `present_time` varchar(30) NOT NULL,
  `return_time` varchar(30) NOT NULL,
  `name_clinic` varchar(30) NOT NULL,
  `expected_birthdate` varchar(30) NOT NULL,
  `added_date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinic_record`
--

INSERT INTO `clinic_record` (`clinic_id`, `partient_id`, `present_time`, `return_time`, `name_clinic`, `expected_birthdate`, `added_date`) VALUES
(1, 2, '08/13/2020', '2020-09-13', 'Kwerekwe', '2020-10-31', '08/13/2020 06:22:29'),
(2, 2, '08/13/2020', '2020-08-15', 'Kwerekwe', '2020-08-28', '08/13/2020 06:23:45'),
(3, 2, '2020-08-13', '2020-08-28', 'Kwerekwe', '2020-08-27', '2020-08-13 06:27:34'),
(4, 2, '2020-08-13', '2020-08-28', 'Kwerekwe', '2020-08-27', '2020-08-13 06:29:36');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL,
  `d_name` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `address` varchar(15) NOT NULL,
  `clinic_name` varchar(30) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `password1` varchar(50) NOT NULL,
  `register_date` varchar(25) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `d_name`, `Username`, `address`, `clinic_name`, `phone_number`, `password1`, `register_date`, `admin_id`, `gender`) VALUES
(1, 'doctor', 'doctor', 'Kwerekwe', 'Kibweni', '0778277832', '81dc9bdb52d04dc20036dbd8313ed055', '8/13/2020', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `lab_result`
--

CREATE TABLE `lab_result` (
  `lab_id` int(11) NOT NULL,
  `partient_id` int(11) NOT NULL,
  `blood_type` varchar(30) NOT NULL,
  `blood_pressure` varchar(30) NOT NULL,
  `blood_load` varchar(30) NOT NULL,
  `weight` varchar(30) NOT NULL,
  `clinic_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `partient`
--

CREATE TABLE `partient` (
  `partient_id` int(11) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `address` varchar(15) NOT NULL,
  `sex` varchar(5) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `password1` varchar(50) NOT NULL,
  `register_date` varchar(25) NOT NULL,
  `doctor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `partient`
--

INSERT INTO `partient` (`partient_id`, `p_name`, `Username`, `address`, `sex`, `phone_number`, `password1`, `register_date`, `doctor_id`) VALUES
(2, 'Test', 'qwss', '1qqqq', 'Male', '123456', 'fcea920f7412b5da7be0cf42b8c93759', '2020-08-13 05:25:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `past_record`
--

CREATE TABLE `past_record` (
  `past_id` int(11) NOT NULL,
  `partient_id` int(11) NOT NULL,
  `no_pregnet` varchar(15) NOT NULL,
  `living_child` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `clinic_record`
--
ALTER TABLE `clinic_record`
  ADD PRIMARY KEY (`clinic_id`),
  ADD KEY `p_name` (`partient_id`),
  ADD KEY `partient_id` (`partient_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `lab_result`
--
ALTER TABLE `lab_result`
  ADD PRIMARY KEY (`lab_id`),
  ADD KEY `partient_id` (`partient_id`,`clinic_id`),
  ADD KEY `clinic_id` (`clinic_id`);

--
-- Indexes for table `partient`
--
ALTER TABLE `partient`
  ADD PRIMARY KEY (`partient_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `past_record`
--
ALTER TABLE `past_record`
  ADD PRIMARY KEY (`past_id`),
  ADD KEY `partient_id` (`partient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `clinic_record`
--
ALTER TABLE `clinic_record`
  MODIFY `clinic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lab_result`
--
ALTER TABLE `lab_result`
  MODIFY `lab_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `partient`
--
ALTER TABLE `partient`
  MODIFY `partient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `past_record`
--
ALTER TABLE `past_record`
  MODIFY `past_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clinic_record`
--
ALTER TABLE `clinic_record`
  ADD CONSTRAINT `clinic_record_ibfk_1` FOREIGN KEY (`partient_id`) REFERENCES `partient` (`partient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor`
--
ALTER TABLE `doctor`
  ADD CONSTRAINT `doctor_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lab_result`
--
ALTER TABLE `lab_result`
  ADD CONSTRAINT `lab_result_ibfk_1` FOREIGN KEY (`partient_id`) REFERENCES `partient` (`partient_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lab_result_ibfk_2` FOREIGN KEY (`clinic_id`) REFERENCES `clinic_record` (`clinic_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partient`
--
ALTER TABLE `partient`
  ADD CONSTRAINT `partient_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `past_record`
--
ALTER TABLE `past_record`
  ADD CONSTRAINT `past_record_ibfk_1` FOREIGN KEY (`partient_id`) REFERENCES `partient` (`partient_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

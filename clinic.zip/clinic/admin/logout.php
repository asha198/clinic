<?php
	session_start();
	//insert into log activity
	include('../connect.php'); //connection
		session_destroy();
	header('Location: ../index.php');
	exit;
?>
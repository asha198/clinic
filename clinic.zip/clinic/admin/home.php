<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="table-responsive ">          
      <b><center><span style="color:#00008B; font-size: 30px; font-family: Tahoma;">Welcome</span><br><br>
      <span style="color:#00008B; font-size: 24px; font-family: Tahoma;">In</span><br><br>
      <span style="color:#00008B; font-size: 24px; font-family: Tahoma;">Clinic Card Record  System</span><br><br>
      </center>
      <br>
  </div>
			</div>
		</div>
	</div>

</body>
</html>
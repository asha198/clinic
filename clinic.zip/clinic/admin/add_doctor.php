<!DOCTYPE html>
<html>
<head>
<?php include "header.php";
session_start();
?>
</head>

  
<div class="container">

  <div class="row justify-content-center">
      <div class="col-md-12">
      <div class="panel panel-primary">
    <div class="panel-heading"><h2>Add Doctor</h2></div>
    <div class="panel-body">
      <form action="add_doctor.php" method="post">
              
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Full Name</label>
                  <input type="text" name="name" id="" placeholder="Doctor Name here" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Username</label>
                  <input type="text" name="username" id="" placeholder="Doctor Username" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Address</label>
                  <input type="text" name="address" id="" placeholder="Doctor Address" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Phone Number</label>
                  <input type="text" name="phone" id="" placeholder="Doctor Phone Number" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Clinic Name</label>
                  <input type="text" name="clinic" class="form-control" placeholder="Clinic Name">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" name="password" id="" placeholder="Doctor Password" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Register Date</label>
                  <input type="text" name="date" id="" class="form-control" readonly value="<?php echo (date('Y-m-d h:i:s'));?>">
                </div>
                  </div>
                  
    </div>
    <div class="panel-footer"><input type="submit" class="btn btn-primary" value="Save" name="save"></div>
    </form>
  </div>
    </div> 
</div>

</div>

</body>
</html>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST["save"])) {
  $name = $conn->real_escape_string($_POST["name"]);
  $address = $conn->real_escape_string($_POST["address"]);
  $phone = $conn->real_escape_string($_POST["phone"]);
  $clinic = $conn->real_escape_string($_POST["clinic"]);
  $username = $conn->real_escape_string($_POST["username"]);
  $password = $conn->real_escape_string($_POST["password"]);
  $date = $conn->real_escape_string($_POST["date"]);
  $admin_id = 1;//$_SESSION["a_id"];
  $Password = md5($password);
//  if (!empty($name) AND !empty($address) AND !empty($phone) AND !empty($clinic) AND !empty($username) AND !empty($password) AND !empty($date) AND !empty($admin_id)) {
  $sql ="INSERT INTO doctor(d_name,Username, address, clinic_name, phone_number, password1, register_date, admin_id)  VALUES('$name','$username','$address','$clinic','$phone','$Password','$date','$admin_id')";
  $query = mysqli_query($conn,$sql);
  //echo $sql;
}
<!DOCTYPE html>
<html>
<head>
<?php include "header.php";?>
</head>

  
<div class="container">

  <div class="row justify-content-center">
      <div class="col-md-12">
      <div class="panel panel-primary">
    <div class="panel-heading"><h2>Laboratory Result</h2></div>
    <div class="panel-body">
      <form action="lab_result.php" method="post">
              
                  <div class="col-md-6">
                <div class="form-group">
                   <label>Partient Name</label>
                  <select class="form-control" name="pname">
                    <option value="">Select Partient Name here</option>
                    <?php $select = "SELECT * FROM partient";
                    $query = mysqli_query($conn,$select);
                    while ($rows = mysqli_fetch_assoc($query)) {
                      ?>
                      <option value="<?php echo($rows['partient_id']);?>"><?php echo($rows['p_name']);?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Blood Type</label>
                  <input type="text" name="bloodtype" id="" placeholder="Blood Type" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Blood Pressure</label>
                  <input type="text" name="bloodpressure" id="" placeholder="Blood Pressure" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Blood Load</label>
                  <input type="text" name="bloodload" id="" placeholder="Blood Load" class="form-control">
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-group">
                  <label>Weight</label>
                  <input type="text" name="weight" id="" placeholder="Weight" class="form-control">
                </div>
              </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Clinic Id</label>
                  <select name="cid" id="" class="form-control">
                     <option value="">Select Clinic Id here</option>
                    <?php $select = "SELECT * FROM clinic_record";
                    $query = mysqli_query($conn,$select);
                    while ($rows = mysqli_fetch_assoc($query)) {
                      ?>
                      <option value="<?php echo($rows['clinic_id']);?>"><?php echo($rows['clinic_id']);?></option>
                      <?php
                    }
                    ?>
                  </select>                
                </div>
                  </div>
                  
    </div>
    <div class="panel-footer"><input type="submit" class="btn btn-primary" value="Save" name="save"></div>
    </form>
  </div>
    </div> 
</div>

</div>

</body>
</html>
<?php
if (isset($_POST["save"])) {
  $pname = mysqli_real_escape_string($conn,$_POST["pname"]);
  $bloodload = mysqli_real_escape_string($conn,$_POST["bloodload"]);
  $bloodpressure = mysqli_real_escape_string($conn,$_POST["bloodpressure"]);
  $bloodtype = mysqli_real_escape_string($conn,$_POST["bloodtype"]);
  $weight = mysqli_real_escape_string($conn,$_POST["weight"]);
  $cid = mysqli_real_escape_string($conn,$_POST["cid"]);
  if (!empty($pname) AND !empty($bloodload) AND !empty($bloodtype) AND !empty($bloodpressure) AND !empty($weight) AND !empty($cid)) {
    $sql = "INSERT INTO lab_result( partient_id, blood_type, blood_pressure, blood_load, weight, clinic_id)  VALUES('$pname','$bloodtype','$bloodpressure','$bloodload','$weight','$cid')";
    $query = mysqli_query($conn,$sql);

    if ($query) {
     echo "<script>alert('New Laboratory result has been saved');</script>";
     echo "<script>open('lab_result.php','_self');</script>";
    }else{
      echo "<script>alert('Data failed to save');</script>";
     // echo(mysqli_error($conn));
      echo "<script>open('lab_result.php','_self');</script>";
    }
  }else{
    echo "<script>alert('Please fill all field');</script>";
  }
}

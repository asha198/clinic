<!DOCTYPE html>
<html>
<head>
<?php include "header.php";?>
</head>

  
<div class="container">

  <div class="row justify-content-center">
      <div class="col-md-12">
      <div class="panel panel-primary">
    <div class="panel-heading"><h2>Clinic Record</h2></div>
    <div class="panel-body">
      <form action="clinic_record.php" method="post">
              
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Partient Name</label>
                  <select class="form-control" name="pname">
                    <option value="">Select Partient Name here</option>
                    <?php $select = "SELECT * FROM partient";
                    $query = mysqli_query($conn,$select);
                    while ($rows = mysqli_fetch_assoc($query)) {
                      ?>
                      <option value="<?php echo($rows['partient_id']);?>"><?php echo($rows['p_name']);?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Clinic Name</label>
                  <input type="text" name="cname" id="" placeholder="Present Time" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Present Time</label>
                  <input type="text" readonly name="ptime" id="" placeholder="Present Time" value="<?php echo (date('Y-m-d'));?>" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Return time</label>
                  <input type="date" name="rtime" id="" placeholder="Return Time" class="form-control">

                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Expected Date Birth</label>
                  <input type="date" name="extime" id="" placeholder="Doctor Password" class="form-control">
                </div>
                  </div>
                  
                  
    </div>
    <div class="panel-footer"><input type="submit" class="btn btn-primary" value="Save" name="save"></div>
    </form>
  </div>
    </div> 
</div>

</div>

</body>
</html>
<?php
if (isset($_POST["save"])) {
  $pname = mysqli_real_escape_string($conn,$_POST["pname"]);
  $ptime = mysqli_real_escape_string($conn,$_POST["ptime"]);
  $rtime = mysqli_real_escape_string($conn,$_POST["rtime"]);
  $cname = mysqli_real_escape_string($conn,$_POST["cname"]);
  $extime = mysqli_real_escape_string($conn,$_POST["extime"]);
  $add_date = mysqli_real_escape_string($conn,date('Y-m-d h:i:s'));
  if (!empty($pname) AND !empty($ptime) AND !empty($rtime) AND !empty($cname) AND !empty($extime) AND !empty($add_date)) {
    $sql = "INSERT INTO clinic_record( partient_id, present_time, return_time, name_clinic, expected_birthdate, added_date)  VALUES('$pname','$ptime','$rtime','$cname','$extime','$add_date')";
    $query = mysqli_query($conn,$sql);

    if ($query) {
    echo $id = $conn->insert_id;
     echo "<script>alert('New clinic record has been saved');</script>";
     echo "<script>alert('Give partient this no $id');</script>";
     echo "<script>open('clinic_record.php','_self');</script>";
    }else{
      echo "<script>alert('Data failed to save');</script>";
     // echo(mysqli_error($conn));
      echo "<script>open('clinic_record.php','_self');</script>";
    }
  }else{
    echo "<script>alert('Please fill all field');</script>";
  }
}


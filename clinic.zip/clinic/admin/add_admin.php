<!DOCTYPE html>
<html>
<head>
<?php include "header.php";?>
</head>

  
<div class="container">

  <div class="row justify-content-center">
      <div class="col-md-12">
      <div class="panel panel-primary">
    <div class="panel-heading"><h2>Add Admin Account</h2></div>
    <div class="panel-body">
      <form action="add_admin.php" method="post">
              
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Full Name</label>
                  <input type="text" name="name" id="" placeholder="Admin Name here" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Username</label>
                  <input type="text" name="username" id="" placeholder="Admin Username" class="form-control">
                </div>
              </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Address</label>
                  <input type="text" name="address" id="" placeholder="Admin Address" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Phone Number</label>
                  <input type="text" name="phone" id="" placeholder="Admin Phone Number" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Clinic Name</label>
                  <input type="text" name="clinic" class="form-control" placeholder="Clinic name">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" name="password" id="" placeholder="Admin Password" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Register Date</label>
                  <input type="text" name="date" id="" class="form-control" readonly value="<?php echo (date('Y-m-d h:i:s'));?>">
                </div>
                  </div>
                  
    </div>
    <div class="panel-footer"><input type="submit" class="btn btn-primary" value="Save" name="save"></div>
    </form>
  </div>
    </div> 
</div>

</div>

</body>
</html>
<?php
if (isset($_POST["save"])) {
  $name = mysqli_real_escape_string($conn,$_POST["name"]);
  $address = mysqli_real_escape_string($conn,$_POST["address"]);
  $phone = mysqli_real_escape_string($conn,$_POST["phone"]);
  $clinic = mysqli_real_escape_string($conn,$_POST["clinic"]);
  $username = mysqli_real_escape_string($conn,$_POST["username"]);
  $password = mysqli_real_escape_string($conn,$_POST["password"]);
  $date = mysqli_real_escape_string($conn,$_POST["date"]);
  $doctor_id = $_SESSION["d_id"];
  $Password = md5($password);
  if (!empty($name) AND !empty($address) AND !empty($phone) AND !empty($clinic) AND !empty($username) AND !empty($password) AND !empty($date) AND !empty($doctor_id)) {
    $sql = "INSERT INTO admin (a_name, Username, address, phone_number, clinic_name, password1,Register_date)  VALUES('$name','$username','$address','$phone','$clinic','$Password','$date')";
    $query = mysqli_query($conn,$sql);

    if ($query) {
      echo "<script>alert('New admin has been saved');</script>";
        echo "<script>open('add_admin.php','_self');</script>";
    }else{
      echo "<script>alert('Data failed to save');</script>";
     // echo(mysqli_error($conn));
      echo "<script>open('add_admin.php','_self');</script>";
    }
  }else{
    echo "<script>alert('Please fill all field');</script>";
  }
}

<?php
	include('../connect.php');
	$catid=$_GET['del'];
        $sql=mysqli_query($conn,"delete from doctor where doctor_id='$catid'");
        header("location:view_doctor.php");
?>
<!DOCTYPE html>
<html>
<head>
<?php include "header.php";
$catid=$_GET['catid'];
$sql="select * from doctor where doctor_id='$catid'";
$query = mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($query);
?>
</head>

  
<div class="container">

  <div class="row justify-content-center">
      <div class="col-md-12">
      <div class="panel panel-primary">
    <div class="panel-heading"><h2>Add Doctor</h2></div>
    <div class="panel-body">
      <form action="add_doctor.php" method="post">
              
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Full Name</label>
                  <input type="text"  value="<?php echo $row['d_name']?>"name="name" id="" placeholder="Doctor Name here" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Username</label>
                  <input type="text"  value="<?php echo $row['Username']?>"name="username" id="" placeholder="Doctor Username" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Address</label>
                  <input type="text" name="address" value="<?php echo $row['address']?>"id="" placeholder="Doctor Address" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Phone Number</label>
                  <input type="text" name="phone" value="<?php echo $row['phone_number']?>"id="" placeholder="Doctor Phone Number" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Clinic Name</label>
                  <input type="text" value="<?php echo $row['clinic_name']?>"name="clinic" class="form-control" placeholder="Clinic Name">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" value="<?php echo $row['password1']?>" name="password" id="" placeholder="Doctor Password" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <label>Register Date</label>
                  <input type="text" name="date" id="" class="form-control" readonly value="<?php echo (date('Y-m-d h:i:s'));?>">
                </div>
                  </div>
                  
    </div>
    <div class="panel-footer"><input type="submit" class="btn btn-primary" value="Save" name="save"></div>
    </form>
  </div>
    </div> 
</div>

</div>

</body>
</html>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST["save"])) {
  $name = $conn->real_escape_string($_POST["name"]);
  $address = $conn->real_escape_string($_POST["address"]);
  $phone = $conn->real_escape_string($_POST["phone"]);
  $clinic = $conn->real_escape_string($_POST["clinic"]);
  $username = $conn->real_escape_string($_POST["username"]);
  $password = $conn->real_escape_string($_POST["password"]);
  $date = $conn->real_escape_string($_POST["date"]);
 // $admin_id = 1;//$_SESSION["a_id"];
  $Password = md5($password);
  $update="update doctor set d_name='$name',Username='$username',address='$address',clinic_name='$clinic',phone_number='$Password'where doctor_id='$catid'";
  $uq= mysqli_query($conn, $update);
}

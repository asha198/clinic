<?php date_default_timezone_set("Africa/Dar_es_Salaam");

include "../connect.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title>Clinic Card Record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script type="text/javascript" src="../js/jquery.min.js"></script>
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <style type="text/css">
    .container{
      margin-top: 100px;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Clinic Card</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Doctor <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="add_doctor.php">Add Doctor</a></li>
          <li><a href="view_doctor.php">Manage Doctor</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Partient <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="add_partient.php">Add Partient</a></li>
          <li><a href="view_partient.php">Manage Partient</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Clinic <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="clinic_record.php">Add Clinic</a></li>
          <li><a href="view_clinic.php">Manage Clinic</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Laboratory <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="lab_result.php">Add Result</a></li>
          <li><a href="view_lab.php">Manage Result</a></li>
        </ul>
      </li>
      
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Admin <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="add_admin.php">Add Admin</a></li>
          <li><a href="view_admin.php">Manage admin</a></li>
        </ul>
      </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      
      <li><a href="logout.php" style="color: red"> Logout</a></li>
      </ul>

  </div>
</nav>
  

</body>
</html>

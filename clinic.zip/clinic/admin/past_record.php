<!DOCTYPE html>
<html>
<head>
<?php include "header.php";?>
</head>

  
<div class="container" style="margin-top: 20px">

  <div class="row justify-content-center">
      <div class="col-md-12">
      <div class="panel panel-primary">
    <div class="panel-heading"><h2>Add Partient</h2></div>
    <div class="panel-body">
      <form action="index.php" method="post">
              
                  <div class="col-md-6">
                <div class="form-group">
                  <input type="text" name="" id="" placeholder="Partient Name here" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <input type="text" name="" id="" placeholder="Partient Address" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <input type="text" name="" id="" placeholder="Partient Phone Number" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <select name="" id="" class="form-control">
                      <option value="">Select your gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                  </select>
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <input type="text" name="" id="" placeholder="Doctor Password" class="form-control">
                </div>
                  </div>
                  <div class="col-md-6">
                <div class="form-group">
                  <input type="text" name="" id="" class="form-control" readonly value="<?php echo (date('Y-m-d h:i:s'));?>">
                </div>
                  </div>
                  </form>
    </div>
    <div class="panel-footer"><input type="" class="btn btn-primary" value="Save" name="save"></div>
  </div>
    </div> 
</div>

</div>

</body>
</html>
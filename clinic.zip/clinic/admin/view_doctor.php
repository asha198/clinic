<?php
session_start();
//error_reporting(0);
include('../connect.php');
   
if(isset($_GET['del'])){    
$doctor_id=substr(base64_decode($_GET['del']));
$query=mysqli_query($conn,"delete from doctor where doctor_id='$doctor_id'");
echo "<script>alert('Doctor record deleted.');</script>";   
echo "<script>window.location.href='view_doctor.php'</script>";
}
?>

<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="table-responsive ">          
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Fullname</th>
        <th>Address</th>
        <th>Clinic Name</th>
        <th>Phone</th>
        <th>Register With</th>
        <th>Register Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
       <?php $select = "SELECT * FROM admin INNER JOIN doctor ON doctor.admin_id = admin.admin_id ORDER BY doctor_id DESC";
      $query = mysqli_query($conn,$select);
      while ($rows = mysqli_fetch_assoc($query)) {
        ?>
        <tr>
        <td><?php echo($rows['doctor_id']) ?></td>
        <td><?php echo($rows['d_name']) ?></td>
        <td><?php echo($rows['address']) ?></td>
        <td><?php echo($rows['clinic_name']) ?></td>
        <td><?php echo($rows['phone_number']) ?></td>
        <td><?php echo($rows['a_name']) ?></td>
        <td><?php echo($rows['register_date']) ?></td>
        <td><a href="edit_doctor.php?catid=<?php echo $rows['doctor_id'];?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> <i class="icon-pencil"></i>Edit</a> ||
            <a href="deletedoctor.php?del=<?php echo $rows['doctor_id'];?>" data-toggle="tooltip" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="icon-trash txt-danger"></i>Delete </a>

      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  </div>
			</div>
		</div>
	</div>

</body>
</html>
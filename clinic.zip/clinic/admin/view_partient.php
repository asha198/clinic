<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="table-responsive ">          
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Fullname</th>
        <th>Address</th>
        <th>Sex</th>
        <th>Phone Number</th>
        <th>Register With</th>
        <th>Register Date</th>
      </tr>
    </thead>
    <tbody>
      <?php $select = "SELECT * FROM doctor INNER JOIN partient ON partient.doctor_id = doctor.doctor_id ORDER BY partient_id DESC";
      $query = mysqli_query($conn,$select);
      while ($rows = mysqli_fetch_assoc($query)) {
        ?>
        <tr>
        <td><?php echo($rows['partient_id']) ?></td>
        <td><?php echo($rows['p_name']) ?></td>
        <td><?php echo($rows['address']) ?></td>
        <td><?php echo($rows['sex']) ?></td>
        <td><?php echo($rows['phone_number']) ?></td>
        <td><?php echo($rows['d_name']) ?></td>
        <td><?php echo($rows['register_date']) ?></td>
      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  </div>
			</div>
		</div>
	</div>

</body>
</html>
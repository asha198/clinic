<?php

$conn= mysqli_connect("localhost","root","??Admin123!","clinicdb") or die("Connection failed ").mysqli_error($conn);

?>

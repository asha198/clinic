<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="table-responsive ">          
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Fullname</th>
        <th>Address</th>
        <th>Clinic Name</th>
        <th>Phone</th>
        <th>Register With</th>
        <th>Register Date</th>
      </tr>
    </thead>
    <tbody>
       <?php $select = "SELECT * FROM admin INNER JOIN doctor ON doctor.admin_id = admin.admin_id ORDER BY doctor_id DESC";
      $query = mysqli_query($conn,$select);
      while ($rows = mysqli_fetch_assoc($query)) {
        ?>
        <tr>
        <td><?php echo($rows['doctor_id']) ?></td>
        <td><?php echo($rows['d_name']) ?></td>
        <td><?php echo($rows['address']) ?></td>
        <td><?php echo($rows['clinic_name']) ?></td>
        <td><?php echo($rows['phone_number']) ?></td>
        <td><?php echo($rows['a_name']) ?></td>
        <td><?php echo($rows['register_date']) ?></td>
      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  </div>
			</div>
		</div>
	</div>

</body>
</html>
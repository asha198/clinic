<?php 
include "connect.php";

if (isset($_POST["login"])) {
  $Username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);
  $Password = md5($password);
  $status = mysqli_real_escape_string($conn, $_POST['status']);
if($Username == ""){
      echo "<script>alert('Username must be filled');</script>";
    }else if($password==""){
      echo "<script>alert('Password must be filled');</script>";
    }else if($status==""){
      echo "<script>alert('Please select your status');</script>";
    }else{
      if ($status==1) {
        $sql = "SELECT * FROM admin WHERE Username = '$Username' AND password1 = '$Password'";
      $query = mysqli_query($conn,$sql);
      $rows = mysqli_fetch_assoc($query);
      $name = $rows["Username"];
      $_SESSION["a_id"] = $rows['admin_id'];
      $_SESSION["name"] = $rows["Username"];

      if (mysqli_num_rows($query)>0) {
        echo "<script>alert('Success $name');</script>";
        echo "<script>open('admin/','_self');</script>";
      }else{
        echo "Wrong details";
      }
      }else if ($status == 2) {
        $sql = "SELECT * FROM doctor WHERE Username = '$Username' AND password1 = '$Password'";
      $query = mysqli_query($conn,$sql);
      $rows = mysqli_fetch_assoc($query);
      $name = $rows["Username"];
       $_SESSION["d_id"] = $rows['doctor_id'];
      $_SESSION["name"] = $rows["Username"];

      if (mysqli_num_rows($query)>0) {
        echo "<script>alert('Success $name');</script>";
        echo "<script>open('doctor/','_self');</script>";
      }else{
        echo "Wrong details " .mysqli_error($conn);
      }
      }else{
        $sql = "SELECT * FROM partient WHERE Username = '$Username' AND password1 = '$Password'";
      $query = mysqli_query($conn,$sql);
      $rows = mysqli_fetch_assoc($query);
      $name = $rows["Username"];
      $_SESSION["id"] = $rows['partient_id'];
      $_SESSION["name"] = $rows["Username"];
      $id = $_SESSION["id"];

      if (mysqli_num_rows($query)>0) {
        echo "<script>alert('Success $name');</script>";
        echo "<script>open('view_record.php?id=$id','_self');</script>";
      }else{
        echo "Wrong details";
      }
      }
    }   
  
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login Form 1</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <div class="col-sm-10" style="width: 55%; margin-left: 20%; margin-top: 5%">
    <div class="jumbotron">
      <h2>
        Login Form
      </h2>
      <hr>
    
    <form class="form-horizontal" action="index.php" method="post">
      <div style="color: red" id="error"></div>
      <div class="form-group input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-user">
            
          </span>
        </span>
        <input type="text" name="username" class="form-control" id="username" placeholder="Enter Your Username Here">

      </div>
      

      <div class="form-group input-group">
        <span class="input-group-addon">
          <span class="glyphicon glyphicon-lock">
            
          </span>
        </span>
        <input type="password" name="password" class="form-control" id="password" placeholder="Enter Your Password Here">
      </div>
      <div class="form-group"> 
        <select name="status" class="form-control">
          <option value="">Select your status here</option>
      <option value="3">Partient</option>
      <option value="2">Doctor</option>
      <option value="1">Admin</option>
    </select>
      </div>
    

     <!-- <div class="form-group">
        <label>
          <input type="checkbox" name="remember_me">
          Remember me
        </label>
      </div>
-->
      <div class="form-group">
        <button class="btn btn-primary" id="login" style="width: 100%;" name="login" type="submit">
          SIGN IN
        </button>
      </div>

      <div class="form-group">
        <a href="#" style="margin-left: 75%">Forget Password</a>
      </div>
    </form>
    </div>
  </div>
</div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
</body>
</html>

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include '../assets/DBHelper.php';
$db=new DBHelper();
$rows=$db->getRows('items');

?>
<script type="text/javascript">
$(document).ready(function(){
   $('#addItem').click(function(){
       var itemNo=$('.itemNo').val();
       var itemName=$('.name').val();
       var quantity=$('.name').val();
       var pic=$('.pic').val();
       $.ajax({
           url:"../action/items.php",
           type:"POST",
           async:false,
           data:{
               "done":1,
               "itemNo":itemNo,
               "itemName":itemName,
               "quantity":quantity,
               "pic":pic
           },
           success:function(data){
               
           }
       });
       
   }) ;
});
</script>
<div class="container-fluid">
    <div class="content">
        <div class="row">
            <div class="col-sm-9">
                <h3>List of Items</h3>
            </div>
            <div class="col-sm-3">
                <br>
                <button data-toggle="modal" data-target="#add" class="btn btn-primary form-control">Add</button>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-xl-12">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr>
                            <th>SN</th>
                             <th>Item No</th>
                            <th>Item Name</th>
                            <th>Category</th>
                            <th>Available Quantity</th>
                            <th>Price</th>
                            <th>Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if(!empty($rows))
                        {$count=0;
                        foreach ($row as $row)
                        {$count++;
                           
                        ?>
                            <td><?php echo $count?></td>
                             <td><?php echo $row['itemNo']?></td>
                            <td><?php echo $row['itemName']?></td>
                            <td><?php echo $row['category']?></td>
                            <td><?php echo $row['available']?></td>
                            <td><?php echo number_format($row['price'])?></td>
                            <td><img height="50" width="60"src="../images/<?php echo $row['photo']?>"></td>
                        </tr>
                            <?php }}?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal form -->
<div id="add" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Item</h4>
      </div>
        <form action="../action/items.php" method="post" enctype="multipart/form-data">
      <div class="modal-body">
          <div class="row">
              <div class="col-sm-4">
                  <label><b>Item No</b></label>
                  <input type="text" name="itemNo" class="itemNo text form-control"  required>
              </div>
              <div class="col-sm-4">
                  <label><b>Item Name</b></label>
                  <input type="text" name="itemName" class=" name form-control" required>
              </div>
              
              <div class="col-sm-4">
                  <label><b>Category</b></label>
                  <select name="category" class="form-control" required>
                      <optgroup>
                          <option value="Food">Food</option>
                          <option value="Drinks">Drinks</option>
                          <option value="Chocolates">Chocolates</option>
                          <option value="Snacks">Snacks</option>
                      </optgroup>
                  </select>
              </div>
              
          </div>
          <br>
          <div class="row">
              <div class="col-sm-3">
                  <label><b>Quantity</b></label>
                  <input type="number" name="quantity" class="quantity text form-control"  required>
              </div>
              <div class="col-sm-3">
                  <label><b>Price</b></label>
                  <input type="number" name="price" class="quantity text form-control"  required>
              </div>
              <div class="col-sm-6">
                  <label><b>Photo</b></label>
                  <input type="file" name="pic" class=" pic form-control" required>
              </div>
      </div>
      <div class="modal-footer">
          <input type="submit" name="addItem" id="submit" class="btn btn-primary" value="Send">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
        </form>
    </div>

  </div>
</div>

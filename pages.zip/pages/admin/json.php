<?php


include '../assets/DBHelper.php';
$db=new DBHelper();
$sql=$db->getSingleRow('users', 'username', $_GET['username']);
header("content-type:application/json");
$myjson= json_encode($sql);
echo $myjson;

?>
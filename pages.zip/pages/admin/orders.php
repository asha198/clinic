<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include '../assets/DBHelper.php';
$db=new DBHelper();
$rows=$db->getRows('orders');

?>
<div class="container-fluid">
    <div class="content">
        <div id="error">
            
        </div>
        <div class="row">
            <div class="col-sm-9">
                <h3>List of Orders</h3>
            </div>
            <div class="col-sm-3">
                <br>
                <button data-toggle="modal" data-target="#add" class="btn btn-primary form-control">Add</button>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-xl-12">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr>
                            <th>SN</th>
                            
                            <th>Customer Email</th>
                            <th>Delivery</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            if(!empty($rows))
                            {
                                $count=0;
                            
                                foreach ($rows as $row)
                                {
                                    $count++
                                
                                   
                        ?>
                        <tr>
                            <td><?php echo $count?></td>
                            
                            <td><?php echo $row['customerEmail']?></td>
                            <td><?php echo $row['deliver']?></td>
                            <td><?php 
                            if($row['status']==1)
                            {
                                echo 'Delivered';
                            }
                            else
                            {
                               echo 'Not Delivered'; 
                            }
                            ?></td>
                        </tr>
                            <?php }}?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal form -->

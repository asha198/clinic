<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include '../assets/DBHelper.php';
$db=new DBHelper();
$rows=$db->getRows('users');


?>
<script type="text/javascript">
$(document).ready(function(){
   $('#submit').click(function(){
     
      var name=$('.fname').val()+" "+$(".mname").val()+" "+$(".lname").val();
      var email=$('.email').val();
      var pass=$(".lname").val();
      $.ajax({
          url:"../action/users.php",
          type:"POST",
          async:false,
          data:{
              
              "done":1,
              "username":email,
              "name":name,
              "pass":pass
          },
          success:function(data){
              displayFromDatabase();
              $('#error').html('successfull');
          }
      });
      //
      
   }) ;
  
});
</script>
    
    </script>
<div class="container-fluid">
    <div class="content">
        <div id="error">
            
        </div>
        <div class="row">
            <div class="col-sm-9">
                <h3>List of Users</h3>
            </div>
            <div class="col-sm-3">
                <br>
                <button data-toggle="modal" data-target="#add" class="btn btn-primary form-control">Add</button>
            </div>
            <div class="col-sm-3">
                <br>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-xl-12">
                <table class="table table-responsive table-striped">
                    <thead>
                        <tr>
                            <th>SN</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $json=array();
                            if(!empty($rows))
                            {
                                $count=0;
                            
                                foreach ($rows as $row)
                                {
                                    $count++;
                                                             ?>
                        <tr>
                            <td><?php echo $count?></td>
                             <td><?php echo $row['name']?></td>
                            <td><?php echo $row['username']?></td>
                            <td><?php 
                            if($row['status']==1)
                            {
                                echo 'Active';
                            }
                            else
                            {
                               echo 'Inactive'; 
                            }
                            ?></td>
                            <td>
                                <a href="json.php?name=<?php echo $row['name']?>&username=<?php echo $row['username']?>" class="btn btn-primary">JSON</a>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=0774829635" target="blank">Whatsapp Account</a>
                            </td>
                        </tr>
                            <?php }}?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal form -->
<div id="add" class="modal fade" role="dialog">
  <div class="modal-dialog">
      <script>
function validateEmail()
{
    var email=document.getElementsByClassName("email").value;
    var reg=/[a-z][0-9]\S\.\_/+/@/+/[a-z]/+/[a-z]/i;
    var res=reg.test(email);
    if(res===false)
    {
        alert("Invalid Email");
        return false;
    }
    else 
    {
        return true;
    }
}
</script>
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add User</h4>
      </div>
        <form action="" method="post" onsubmit="return validateEmail();">
      <div class="modal-body">
          
          <div class="row">
              <div class="col-sm-4">
                  <label><b>First Name</b></label>
                  <input type="text" name="name" class="  fname text form-control"  required>
              </div>
              <div class="col-sm-4">
                  <label><b>Middle Name</b></label>
                  <input type="text" name="email" class=" mname form-control" required>
              </div>
              <div class="col-sm-4">
                  <label><b>Last Name</b></label>
                  <input type="text" name="email" class=" lname form-control" required>
              </div>
              
          </div>
          <br>
          <div class="row">
              
              <div class="col-sm-12">
                  <label><b>Email</b></label>
                  <input type="text" name="email" class=" email form-control" required>
              </div>
              
          </div>
      </div>
      <div class="modal-footer">
          <input type="submit" name="add" id="submit" class="btn btn-primary" value="Send">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
        </form>
    </div>

  </div>
</div>

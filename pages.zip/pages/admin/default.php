<?php
include '../assets/DBHelper.php';
$db=new DBHelper();
$rows=$db->getConditionedData("orders","status",0)
?>
<div class="container-fluid">
    <div class="content">
        <div class="row">
            <div col-sm-12">
                <h2>Daily Report</h2>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6">
                
                <div class="well">
                    <?php 
                        if(isset($_GET['msg']))
                        {
                            if($_GET['msg']=='delivered')
                            {
                                echo "<div class='alert alert-success' >Successfully delivered </div>";
                            }
                            
                        }
                        ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>List of orders to be Delivered</h4>
                        </div>
                    </div>
                    <hr>
                <table class="table table-striped">
                    <thead>
                        <tr>
                             <th>SN</th>                            
                            <th>Customer Email</th>
                            <th>Delivery</th>
                            <th>Status</th>                            
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            if(!empty($rows))
                            {
                                $count=0;
                            
                                foreach ($rows as $row)
                                {
                                    $count++
                                
                                   
                        ?>
                        <tr>
                            <td><?php echo $count?></td>
                            
                            <td><?php echo $row['customerEmail']?></td>
                            <td><?php echo $row['deliver']?></td>
                            <td><?php 
                            if($row['status']==1)
                            {
                                echo 'Delivered';
                            }
                            else
                            {
                               echo 'Not Delivered'; 
                            }
                            ?></td>
                            <td>
                                <button data-toggle="modal" data-target="#<?php echo $row['orderNo'] ?>" title="view Items ordered" class="btn btn-info glyphicon glyphicon-eye-open"></button>
                                <a href="../action/order.php?order=1&id=<?php echo $row['orderNo']?>" class=" btn btn-primary glyphicon glyphicon-check"></a>
                            </td>
                        </tr>
                        
<!-- Modal -->
<div id="<?php echo $row['orderNo']?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">View Ordered Items</h4>
      </div>
      <div class="modal-body">
          <div class="row">
              <div class="col-sm-3">S/N</div>
              <div class="col-sm-3">Item Name</div>
              <div class="col-sm-3">Quantity</div>
              <div class="col-sm-3">Amount</div>
          </div>
          <hr>
          <?php 
          $is=$db->getConditionedData('order_items', 'orderNo', $row['orderNo']);
          if(!empty($is))
          {
              $count=0;
          foreach($is as $i)
          {$count++;
              
          
          ?>
          <div class="row">
              <div class="col-sm-3"><?php echo $count?></div>
              <div class="col-sm-3"><?php echo $db->getData('items', 'itemName', 'itemNo', $i['itemNo'])?></div>
              <div class="col-sm-3"><?php echo $i['quantity']?></div>
              <div class="col-sm-3"><?php echo number_format($i['totalAmount'])?></div>
          </div>
          <hr>
          <?php }} ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
                            <?php }}?>

                    </tbody>
                </table>
              </div>
            </div>
            <div class="col-sm-6">
                <div class="well">
                    <div class="row">
                    <div class="col-sm-12">
                        <?php 
                        if(isset($_GET['msg']))
                        {
                            if($_GET['msg']=='itemadded')
                            {
                                echo "<div class='alert alert-success' >Successfully add an item</div>";
                            }
                            
                        }
                        ?>
                    </div>
                </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>List of Finished Items</h4>
                        </div>
                    </div>
                    <hr>
                    <form action="../action/items.php" method="post">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Item Name</th>
                                <th>Available</th>
                                <th>Add</h>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $items=$db->getConditionedData("items", "available", 0);
                                $count=0;
                                if(!empty($items))
                                {
                                    
                                    foreach ($items as $item)
                                    {$count++;
                                ?>
                            <tr>
                                <td><?php echo $count;?></td>
                                <td><?php echo $item['itemName'];?></td>
                                <td><?php echo $item['available']?></td>
                                <td>
                                    <input type="hidden" name="itemNo<?php echo $count?>" value="<?php echo $item['itemNo']?>">
                                    <input min="1" name="quantity<?php echo $count?>" type="number" clolass="form-control">
                                </td>
                            </tr>
                                <?php }
                                
                                ?>
                            <tr>
                                <td colspan="4">
                                    <input type="hidden" name="count" value="<?php echo $count?>">
                                <input type="submit" name="add" class=" btn btn-primary form-control" value="Add Items">
                                </td>
                            </tr>
                                   <?php }else{?>
                            <tr>
                                <td colspan="4">No records found</td>
                            </tr>
                                   <?php }?>
                        </tbody>
                    </table>
                    </form>
                     
                </div>
            </div>
        </div>
    </div>
</div>

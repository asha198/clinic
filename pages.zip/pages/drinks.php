<?php
include 'assets/DBHelper.php';
$db=new DBHelper();
$rows=$db->getConditionedData("items","category","Drinks");
?>
<div class="container-fluid">
    <div class="content">
        <div class="row">
            <div class="col-xl-12">
                <h2>Drinks Category Goods</h2>
            </div>
        </div>
        <hr>
        
                <?php 
                if(!empty($rows))
                {
                    foreach ($rows as $row)
                    {
                    
                 
                ?>
               
        <div class="col-sm-3"><img src="images/<?php echo $row['photo']?>"height="150px" width="200px"/>
                        <br><b><?php echo $row['itemName']?>:<?php echo number_format($row['price'])?>/=</b>
                    </div>
                   
                
                
                <?php }}?>
            
    </div>
</div>
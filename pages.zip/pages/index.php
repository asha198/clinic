<?php 
if(isset($_GET['msg']))
{
    if($_GET['msg']=='succ')
    {
        echo "<script>alert('You have successfully create an account')</script>";
        
    }
 else if($_GET['msg']=='unsucc')
 {
     echo "<script>alert('Account has not been created')</script>";
 }
 }
        
 {
}
?>
<!DOCTYPE>
<html>
    <head>
        <title>Online Shopping</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="bootstrap/css/style.css">
        <script src="bootstrap/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
    </head>
    <body>
       
             <nav class="navbar navbar-fixed-top">
                    <div class="container-fluid">
                      <div class="navbar-header ">
                          <a class="navbar-brand" href="#"><img class="logo"src="images/logo1.jpg" height="58px" width="100" alt="logo"></a>
                      </div>
                      <ul class="nav navbar-nav">
                        <li class="active"><a href="#" id="home">Home</a></li>
                        <li class="dropdown">
                         <a class="dropdown-toggle" data-toggle="dropdown" href="#">Categories
                            <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                  <li><a href="#" id="food">Food</a></li>
                                  <li><a href="#" id="chocolates">Chocolates</a></li>
                                  <li><a href="#" id="drinks">Drinks</a></li>
                                  <li><a href="#" id="snacks">Snacks</a></li>
                                </ul>
                        </li>
                      </ul>
                      <ul class="nav navbar-nav navbar-right">
                        <li><a href="#" id="signup"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>

                        <li><a href="#" id="login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                      </ul>
                    </div>
            </nav> 
            
       <!-- Body -->
       <div class="container-fluid">
           
           <div class="container">
               
             <script>
               $(document).ready(function()
               {
                   
                  $('.container').load('default.php');
                  $('#home').click(function(){
                   $('.container').load('default.php');   
                  });
                   $('#login').click(function(){
                        $('.container').load('login.php');
                   });
                  $('#food').click(function(){
                      $('.container').load('food.php');
                  });
                  $('#chocolates').click(function(){
                      $('.container').load('chocolates.php');
                  });
                  $('#drinks').click(function(){
                      $('.container').load('drinks.php');
                  });
                  $('#snacks').click(function(){
                      $('.container').load('snacks.php');
                  });
                   $('#signup').click(function(){
                      $('.container').load('signup.php');
                  });
               });
           </script>
           
           </div>
               
          
       </div>
     
       <!-- end of body -->
       <nav class="navbar navbar-fixed-bottom">
           <div class="container-fluid">
               <p><i>Made by hamida Ahmed Yussuf...A student of Bachelor of Science in Computer Science in The State University of Zanzibar Second year 2019/2020</i></p>
           </div>
       </nav>
    </body>
</html>

<script type="text/javascript">
    function validate()
    {
            var name=document.getElementById("email").value;
            var password1=document.getElementById("password1").value;
            var password2=document.getElementById("password2").value;
            var phone=document.getElementById("contact").value;
            var pp=/\+255\d/;
            var p=/\w\d@\w.\w/i;
            var p2=/\w@\w.\w/i;
            if(name==="")
            {
                document.getElementById("error").innerHTML="Must Fill in the email";
                
                return false;
            }
            else if(p.test(name)===false)
            {
                document.getElementById("error").innerHTML="Invalid Email Address";
                return false;
            }
            else if(password1==="")
            {
                document.getElementById("error").innerHTML="Must fill in the password";
                return false;
            }
            else if(password1!==password2)
            {
                document.getElementById("error").innerHTML="Password doesnot match";
                return false;
            }
            else if(phone==="")
            {
               document.getElementById("error").innerHTML="Must fill the phone number";
               return false;
            }
            else if(phone.length!==13)
            {
                document.getElementById("error").innerHTML="Invalid Phone Number";
               return false;
            }
            
            else
            {
                return true;
            }
}
</script>
<div class="container-fluid">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h1>Sign up here to Open Account</h1>
            </div>
        </div>
        <hr>
        <div class="well">
            <form action="action/signup.php" method="post" onsubmit="return validate()">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-3">
                        <div class="row">
                            <div class="col-sm-12">
                                <p id="error" style="color:red"></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Email Address</label>
                                <input type="text" id="email"name="email" class="form-control">
                            </div>
                        </div>
                        
                        <br>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Contact</label>
                                <input type="text" id="contact"name="phone" class="form-control">
                            </div>
                        </div>
                        
                        <br>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Password</label>
                                <input type="password" id="password1"name="password" class="form-control">
                            </div>
                        </div>
                        <br>
                         <div class="row">
                            <div class="col-sm-12">
                                <label>Confirm Password</label>
                                <input type="password" id="password2"name="confirm" class="form-control">
                            </div>
                        </div>
                        
                        <br>
                        <div class="row">
                            <div class="col-sm-12">
                               
                                <input type="submit" id="submit"name="submit" value="Send" class="btn btn-primary form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
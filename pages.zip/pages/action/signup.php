<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include '../assets/DBHelper.php';
$db=new DBHelper();
if(isset($_POST['submit']))
{
    try{
    $username=$_POST['email'];
    $password=sha1($_POST['password']);
    $phone=$_POST['phone'];
    $data= array($username,$phone,$password,1);
    $db->insert("customers",$data); 
   
    $check= $db->checkIFExist("cart", "customer", $username) ;
    if($check==0)
    {
       
       $insertCart=$db->insert("cart",array($db->generateID("cart", "cartID"),$username));
     
    
    }
    
       
       header("location:../index.php?msg=succ");
  
    }
    catch(PDOException $e)
    {
        header("location:../index.php?msg=unsucc");
    }
}
    ?>


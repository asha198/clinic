<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include '../assets/DBHelper.php';
$db=new DBHelper();

if(isset($_GET["done"]))
{
    $cartItemID=$_GET['id'];
 
 $delete=$db->delete('cartItem', 'cartItemID', $cartItemID);
 
    if($delete==1)
    {
    header("location:../customer/index.php?gs=my_cart&msg=del");
    }
    else
    {
        header("location:../customer/index.php?gs=my_cart&msg=not");
    }
}
if(isset($_POST['order']))
{
    $orderNo=$db->generateID('orders', "orderNo");    
    $delivery=$_POST['delivery'];
    $status=0;
    $customerEmail=$_SESSION['user'];
    $table1=
    $table2="order_items";
    $count=$_POST['count'];
    $cartID=$db->getData('cart', 'cartID', 'customer', $customerEmail);
     $data=array($orderNo,$delivery,$status,$customerEmail);
     $insert=$db->insert('orders', $data);
    for($i=1;$i<=$count;$i++)
    {
        $orderItemNo=$db->generateID($table2, "orderItemNo");
        $available=$_POST['available'.$i];
       
        $itemNo=$_POST['itemNo'.$i];
        $quantity=$_POST['quantity'.$i];
        if($available<$quantity)
        {
            $quantity=$available;
        }
        $total=$db->getData('items', 'price', 'itemNo', $itemNo)*$quantity;
        $d=array($orderItemNo,$orderNo,$itemNo,$quantity,$total);
        $insertItems=$db->insert($table2, $d);
        
         $delete=$db->delete('cartItem', 'cartID', $cartID);
         $update=$db->update('items', array('available'=>$available-$quantity), array('itemNo'=>$itemNo));
    
        }
  
    header("location:../customer/index.php?msg=order");
}
if(isset($_GET['order']))
{
    $orderNo=$_GET['id'];
    $update=$db->update('orders', array('status'=>1), array('orderNo'=>$orderNo));
    header("location:../admin/index.php?msg=delivered");
}
?>


<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
//include '../assets/dbConnection.php';
include '../assets/DBHelper.php';
$db=new DBHelper();

if(isset($_POST['submit']))
{
    $password=sha1($_POST['password']);
    $username=$_POST['username'];
    if($db->login("users",$username, $password)==1)
    {
        
        header("location:../admin/index.php");
    }
    else{
        if($db->login("customers",$username,$password)==1)
           {      
        
             header("location:../customer/index.php"); 
           }
           else{
            header("location:../index.php"); 
        }
    }
    
    
    
   
 }
 
?>
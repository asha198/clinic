
<?php
include '../assets/DBHelper.php';
$db=new DBHelper();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if(isset($_POST['addItem']))
{
    
  try{
  $itemNo=$_POST['itemNo'];
  $itemName=$_POST['itemName'];
  $quantity=$_POST['quantity'];  
  $available=$_POST['quantity'];
  $price=$_POST['price'];
  $category=$_POST['category'];
  
  
  $target_dir = "../images/";
  $file= basename($_FILES["pic"]["name"]);
    $target_file = $target_dir . basename($_FILES["pic"]["name"]);
    if ($_FILES["pic"]["size"] > 500000) {
        echo 'size';
    }
    move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);
    
        $data=array($itemNo,$itemName,$quantity,$available,$file,$price,$category);
  
        $insert=$db->insert('items', $data);
    if($insert)
    {
       header("location:../admin/index.php");
    }
    else{
          header("location:../admin/index.php?msg=exist");
    }

    } catch (PDOException $e)
    {
        header("location:../admin/index.php?id=items");
    }
      
  
  
  
}
if(isset($_POST['add']))
{  
       
    $count=$_POST['count'];
    for($i=1;$i<=$count;$i++)
    {
        $itemNo=$_POST['itemNo'.$i];
        $quantity=$_POST['quantity'.$i];
        if($quantity!='')
        {
            echo $quantity;
            $update=$db->update('items', array('available'=>$quantity), array('itemNo'=>$itemNo));
            header("location:../admin/index.php?msg=itemadded");
        }
    }
}
?>
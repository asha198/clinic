<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$username=$_SESSION['user'];
include '../assets/DBHelper.php';
$db=new DBHelper();
if(isset($_GET['done']))
{
$itemNo=$_GET['id'];
$id=$db->generateID("cartItem", "cartItemID");
$cartID=$db->getData('cart', 'cartID', 'customer', $username);
$check_c=$db->checkIFExist('cartItem', 'cartID', $cartID);
$check_i=$db->checkIFExist('cartItem', 'itemNo', $itemNo);
echo $check_c;
        echo $check_i;

if($check_c==1)
{
    if($check_i==1)
    {
        
    header("location:../customer/index.php?gs=view&msg=exist&id=".$itemNo);
    }
    else{
$insert=$db->insert("cartItem", array($id,$itemNo,$cartID));
header("location:../customer/index.php?gs=view&msg=cart&id=".$itemNo);
}

}

}
?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
//include '../assets/dbConnection.php';
include '../assets/DBHelper.php';
$db=new DBHelper();

if(isset($_POST['done']))
{
    try{
  $username=$_POST['username'];
  $status=1;
  $password=sha1($_POST['pass']);
  $name=$_POST['name'];
 
  
  $data=array($username,$password,$status,$name);
  
     $insert=$db->insert('users', $data);

    } catch (PDOException $e)
    {
        header("location:../admin/index.php?id=unsucc");
    }
      
  
  
  
}


 ?>




<div class="container-fluid">
    <div class="content">
       <div class="row">
           
            <div class="col-sm-6">
                <h3>Login to Update Items</h3>
                            
            </div>
       </div>
        <hr>
        
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
                <div class="jumbotron">
                   
                    <form action="action/login.php " method="post">
                    <div class="row">
                        <div class="col-sm-12">
                            
                            <label>Username</label>
                            <input type="text" name="username"class="form-control" required>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12">
                            <label>Password</label>
                            <input type="password" name="password"class="form-control" required>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12">
                            <input type="submit" name="submit"class="btn btn-info form-control" value="Login">
                        </div>
                    </div>
                </form>  
                </div>
            </div>
        </div>       
    </div>
</div>

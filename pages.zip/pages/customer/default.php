<?php
include '../assets/DBHelper.php';
$db=new DBHelper();
$rows=$db->getRows("items");
?>

<div class="container-fluid">
    <div class="content">
        <div class="row">
            <div class="col-xl-12">
                <div class="well"><h3>Welcome to our Grocery...Order your items online and save your time...Shop online with us</h3></div>
            </div>
        </div>
        <div class="row">
                    <div class="col-sm-12">
                        <?php 
                        if(isset($_GET['msg']))
                        {
                            if($_GET['msg']=='order')
                            {
                                echo "<div class='alert alert-success' >Your order has been sent successfully</div>";
                            }
                            
                        }
                        ?>
                    </div>
                </div>
        <div class="row">
            <div class="col-sm-12">
                <?php 
                if(!empty($rows))
                {
                    foreach ($rows as $row)
                    {
                    
                 
                ?>
               
                <div class="col-sm-3"><a href="index.php?gs=view&id=<?php echo $row['itemNo']?>" onclick="getData();"><img src="../images/<?php echo $row['photo']?>"height="150px" width="200px"/></a>
                        <br><b><?php echo $row['itemName']?>:<?php echo number_format($row['price'])?>/=</b>
                    </div>
                
                
                <?php }}?>
            </div>
        </div>
    </div>
</div>
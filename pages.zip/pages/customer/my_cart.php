<?php
session_start();
include '../assets/DBHelper.php';
$db=new DBHelper();
?>

<div class="container-fluid">
    <div class="content">
                     <div class="row">
                    <div class="col-sm-8">
                        <h2>List of Items in a Cart</h2>
                    </div>
                         
                </div>
                
                <hr>
                <div class="row">
                    <div class="col-sm-12">
                        <?php 
                        if(isset($_GET['msg']))
                        {
                            if($_GET['msg']=='cart')
                            {
                                echo "<div class='alert alert-success' >Successfully add an item to cart</div>";
                            }
                            if($_GET['msg']=='del')
                            {
                                echo "<div class='alert alert-success' >Successfully delete an item from a cart</div>";
                            }
                        }
                        ?>
                    </div>
                </div>
                <form action="../action/order.php" method="post">
                <div class="row">
                    <div class="col-sm-12">
                        <table class="table table-responsive-sm table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Item Name</th>
                                    <th>Available</th>
                                    <th>Quantity</th>
                                    <th>Drop</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $count=0;
                                    $cartID=$db->getData('cart', 'cartID', 'customer', $_SESSION['user']);
                                    $rows=$db->getConditionedData('cartItem', 'cartID', $cartID);
                                    if(!empty($rows))
                                    {
                                       
                                        
                                        foreach($rows as $r)
                                        {
                                             $item=$db->getSingleRow('items', 'itemNo', $r['itemNo']);
                                            $count++;
                                            
                                ?>
                                        <tr>
                                            <td><?php echo $count?></td>
                                            <td><input type="hidden" name="itemNo<?php echo $count?>" value="<?php echo $r['itemNo'] ?>"><?php echo $item['itemName']?></td>
                                            <td><input type="hidden" name="available<?php echo $count?>" value="<?php echo $item['available'] ?>"><?php echo $item['available']?></td>
                                            <td><input type="number" min="1" name="quantity<?php echo $count?>" class="form-control" required> </td>
                                            <td><a href="../action/order.php?id=<?php echo $r['cartItemID']?>&done=1" class="btn btn-danger glyphicon glyphicon-trash"></a></td>
                                        </tr>
                                <?php }}else{?>
                                        <tr>
                            <td colspan="5">The Cart is empty</td>
                        </tr>
                            <?php } ?>
                                        <tr>
                                
                                            <td colspan="5">
                                                <input type="hidden" name="count" value="<?php echo $count?>">
                                               
                                            </td>
                                        </tr>
                            </tbody>
                        </table> 
                    </div>
                </div>
                    <div class="row" id="hide">
                        <div class="col-sm-6">
                            <label>Delivery</label>
                            <input type="text" name="delivery" required class="form-control">
                        </div>
                        <div class="col-sm-6">
                            <label style="visibility: hidden">Delivery</label>
                         <input type="submit" name="order" value="Order" class="btn btn-primary form-control">
                        </div>
                    </div>
                </form>
    </div>
</div>




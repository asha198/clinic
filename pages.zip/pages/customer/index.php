<?php 
session_start();
if(!isset($_SESSION['user']))
{
    header("location:../index.php");
}
 else {
    
 
?>
<!DOCTYPE>
<html>
    <head>
        <title>Online Shopping</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../bootstrap/css/style.css">
        <script src="../bootstrap/js/jquery.min.js"></script>
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../bootstrap/js/validation.js"></script>
    </head>
    <body>
       
             <nav class="navbar navbar-fixed-top">
                    <div class="container-fluid">
                      <div class="navbar-header ">
                          <a class="navbar-brand" href="#"><img class="logo"src="../images/logo1.jpg" height="58px" width="100" alt="logo"></a>
                      </div>
                      <ul class="nav navbar-nav">
                         <li class="active"><a href="index.php" id="my_cart">Home</a></li>
                        <li class="active"><a href="index.php?gs=my_cart" id="my_cart">My cart</a></li>
                        <li class="active"><a href="index.php?gs=search" id="my_cart">Items</a></li>

                      </ul>
                      <ul class="nav navbar-nav navbar-right">
                          <li><a href="../admin/logout.php"><span class="glyphicon glyphicon-log-out"></span> logout</a></li>
                      </ul>
                    </div>
            </nav> 
       <!-- Body -->
       <div class="container-fluid">
           
           <div class="container">
               
                        <?php 
           switch((isset($_GET['gs'])? $_GET['gs']:''))
           {
                   case 'view':
                       include 'view.php';
                       break;
                   
                   case 'my_cart':
                       include 'my_cart.php';
                       break;
                   
                   case 'search':
                       include 'search.php';
                       break;
                   default:
                       include 'default.php';
           }
           ?>
           
           </div>
               
          
       </div>
       <!-- end of body -->
       <nav class="navbar navbar-fixed-bottom">
           <div class="container-fluid">
               <p><i>Made by hamida Ahmed Yussuf...A student of Bachelor of Science in Computer Science in The State University of Zanzibar Second year 2019/2020</i></p>
           </div>
       </nav>
    </body>
</html>
 <?php } ?>
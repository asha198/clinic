<?php 
include '../assets/DBHelper.php';
$db=new DBHelper();

$itemNo=$_GET['id'];
$row=$db->getSingleRow('items', 'itemNo', $itemNo);
?>

<div class="container-fluid">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h1>View the Item and add to your Cart</h1>
            </div>
        </div>
        <hr>
        <div class="row">
            
        <?php 
        if(isset($_GET['msg']))
        {
            if($_GET['msg']=='cart')
            {
                echo "<div class='alert alert-success' >Successfully add an item to cart</div>";
            }
            else if($_GET['msg']=='exist')
            {
              echo "<div class='alert alert-success' >Item exist in a cart</div>";

            }
        }
        ?>
         </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="well">
                    <div class="row">
                        <div class="col-sm-12">
                            <img src="../images/<?php echo $row['photo']?>" height="300px">
                        </div>
                        
                            
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <p><b>Item Name:</b></p>
                        </div>
                        <div class="col-sm-6">
                            <p><b><?php echo $row['itemName']?></b></p>
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-sm-6">
                            <p><b>Category:</b></p>
                        </div>
                        <div class="col-sm-6">
                            <p><b><?php echo $row['category']?></b></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <p><b>Quantity Available:</b></p>
                        </div>
                        <div class="col-sm-6">
                            <p><b><?php echo $row['available']?></b></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <a class="btn  btn-primary" href="../action/view.php?done=1&id=<?php echo $itemNo?>">Add to Cart</a>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-12">
                        <h4>List of Items in a Cart</h4>
                    </div>
                </div>
                <hr>
                <form action="../action/order.php" method="post">
                <div class="row">
                    <div class="col-sm-12">
                        <table class="table table-responsive-sm table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Item Name</th>
                                    <th>Available</th>
                                    <th>Quantity</th>
                                    <th>Drop</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $count=0;
                                    $cartID=$db->getData('cart', 'cartID', 'customer', $_SESSION['user']);
                                    $rows=$db->getConditionedData('cartItem', 'cartID', $cartID);
                                    if(!empty($rows))
                                    {
                                       
                                        
                                        foreach($rows as $r)
                                        {
                                             $item=$db->getSingleRow('items', 'itemNo', $r['itemNo']);
                                            $count++;
                                            
                                ?>
                                        <tr>
                                            <td><?php echo $count?></td>
                                            <td><input type="hidden" name="itemNo<?php echo $count?>" value="<?php echo $r['itemNo'] ?>"><?php echo $item['itemName']?></td>
                                            <td><input type="hidden" name="available<?php echo $count?>" value="<?php echo $item['available'] ?>"><?php echo $item['available']?></td>
                                            <td><input type="number" min="1" name="quantity<?php echo $count?>" class="form-control" required> </td>
                                            <td><a href="../action/order.php?id=<?php echo $r['cartItemID']?>&done=1" class="btn btn-danger glyphicon glyphicon-trash"></a></td>
                                        </tr>
                                <?php }}else{?>
                                        <tr>
                            <td colspan="5">The Cart is empty</td>
                        </tr>
                            <?php } ?>
                                        <tr>
                                
                                            <td colspan="5">
                                                <input type="hidden" name="count" value="<?php echo $count?>">
                                               
                                            </td>
                                        </tr>
                            </tbody>
                        </table> 
                    </div>
                </div>
                    <div class="row" id="hide">
                        <div class="col-sm-6">
                            <label>Delivery</label>
                            <input type="text" name="delivery" required class="form-control">
                        </div>
                        <div class="col-sm-6">
                            <label style="visibility: hidden">Delivery</label>
                         <input type="submit" name="order" value="Order" class="btn btn-primary form-control">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
    </div>
</div>
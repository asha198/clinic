<?php
include 'dbConnection.php';

class DBHelper{
   private $conn;
    public function __construct() {
        $co=new connection();
        $this->conn=$co->connect();
    }
   
    public function login($table,$username,$password)
    {
       
        $sql= $this->conn->prepare("select * from ".$table." where username=:uname and password =:pass and status=:st",array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $sql->execute(array(':uname'=>$username,':pass'=>$password,':st'=>1));
      
            if($sql->rowCount() >0)
            {
                session_start();
                $user=$sql->fetch();
                $_SESSION['user']=$user['username'];
                return 1;
            }
            else 
            {
                return 0;
             }
       

    }
    
    public function getRows($table)
    {
        $sql=$this->conn->prepare('select * from '.$table);
        $sql->execute();
        return $sql->fetchAll();
    }
    public function insert($table,$data=array())
    {
        $sql="insert into ";
        $sql.=$table;
        $sql.=" values(";
        $v=array();
        if(is_array($data))
        {
            $i=0;
        foreach ($data as $value) {
              $x= array_shift($data);
              $v[$i]="'$x'";
              $i++;
              }
            }
            $sql.= implode(",", $v);
        $sql.=");";
        return $this->conn->exec($sql);
        
    }
    public function getConditionedData($table,$column,$value)
    {
        $sql=$this->conn->prepare("select * from ".$table." where ".$column."=:val");
        $sql->execute(array(':val'=>$value));
         return $sql->fetchAll();
        
    }
    public function checkIFExist($table,$column,$value)
    {
        $result=0;
        $sql=$this->conn->prepare("select * from ".$table." where ".$column."=:val");
        $sql->execute(array(':val'=>$value));
        if($sql->rowCount()>0)
        {
            $result= 1;
        }
        else
        {
            $result= 0;
        }
        return $sql->rowCount();
    }
    public function getSingleRow($table,$column,$value)
    {
        $sql=$this->conn->prepare("select * from ".$table." where ".$column."= :val");
        $sql->execute(array(":val"=>$value));
        return $sql->fetch();
    }
    public function generateID($table,$column)
    {
        $sql=$this->conn->prepare("select * from ".$table." order by ".$column." DESC");
        $sql->execute();
        $row=$sql->fetch();
        return $row[$column]+1; 
        
    }
    public function getData($table,$attribute,$column,$value)
    {
        $sql=$this->conn->prepare("select * from ".$table." where ".$column." =:val");
        $sql->execute(array(':val'=>$value));
        $row=$sql->fetch();
        return $row[$attribute];
    }
    public function delete($table,$column,$value)
    {
        
        $sql=$this->conn->exec("delete from ".$table." where ".$column."=".$value);
        return $sql?1:0;
    }
    public function update($table,$data=array(),$condition=array())
    {
        $sql="update ";
        $sql.=$table;
        $sql.="  set ";
        
        $d=array();
        $i=0;
        foreach($data as $key=>$value)
        {
            $d[$i]=$key."= '$value'";
            $i++;
            
        }
        $sql.= implode(",", $d);
        $sql.=" where ";
        $y=0;
        $c=array();
        foreach($condition as $key=>$value)
        {
            $c[$y]=$key."= '$value'";
        }
        $sql.= implode('and', $c);
        $query=$this->conn->prepare($sql);
        return $query->execute();
    }
    
}


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


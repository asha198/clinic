<?php
error_reporting(E_ALL); 
error_reporting(-1); 
ini_set('error_reporting', E_ALL); 
include 'DBHelper.php';
$db=new DBHelper();
 
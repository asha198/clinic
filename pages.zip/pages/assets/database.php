<?php
$sql="CREATE TABLE `users` (
  `username` varchar(450) NOT NULL,
  `password` longtext NOT NULL,
  `status` int NOT NULL,
  `name` longtext NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
;
INSERT INTO `shop`.`users`
(`username`,
`password`,
`status`,
`name`)
VALUES
('hamy30796@gmail.com','+255777654321','a2cb5f7bb85df88bafe16acc20224e2a181e7fa4',1);
CREATE TABLE `items` (
  `itemNo` varchar(45) NOT NULL,
  `itemName` longtext NOT NULL,
  `quantity` int NOT NULL,
  `available` int NOT NULL,
  `photo` longtext NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `category` varchar(45) NOT NULL,
  PRIMARY KEY (`itemNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `orders` (
  `orderNo` int NOT NULL,
  `deliver` longtext NOT NULL,
  `status` int NOT NULL,
  `customerEmail` varchar(100) NOT NULL,
  PRIMARY KEY (`orderNo`),
  KEY `customerEmail` (`customerEmail`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customerEmail`) REFERENCES `customers` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
;
CREATE TABLE `order_items` (
  `orderItemNo` int NOT NULL,
  `orderNo` int NOT NULL,
  `itemNo` varchar(45) NOT NULL,
  `quantity` int NOT NULL,
  `totalAmount` decimal(10,0) NOT NULL,
  PRIMARY KEY (`orderItemNo`),
  KEY `orderNo` (`orderNo`),
  KEY `itemNo` (`itemNo`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`orderNo`) REFERENCES `orders` (`orderNo`),
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`itemNo`) REFERENCES `items` (`itemNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE `customers` (
  `username` varchar(100) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `password` longtext NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE `cart` (
  `cartID` int NOT NULL,
  `customer` varchar(100) NOT NULL,
  PRIMARY KEY (`cartID`),
  KEY `customer` (`customer`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`customer`) REFERENCES `customers` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
CREATE TABLE `cartItem` (
  `cartItemID` int NOT NULL,
  `itemNo` varchar(45) NOT NULL,
  `cartID` int NOT NULL,
  PRIMARY KEY (`cartItemID`),
  KEY `itemNo` (`itemNo`),
  KEY `cartID` (`cartID`),
  CONSTRAINT `cartItem_ibfk_1` FOREIGN KEY (`itemNo`) REFERENCES `items` (`itemNo`),
  CONSTRAINT `cartItem_ibfk_2` FOREIGN KEY (`cartID`) REFERENCES `cart` (`cartID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

"

?>
<?php

    

    class connection{
      
        public function connect()
        {
        $servername = "localhost";
        $username = "root";
        $password = "??Admin123!";
        $conn;
        try {
          $conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);

          //$thconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          //echo "Connected successfully";
        } catch(PDOException $e) {
          echo "Connection failed: " . $e->getMessage();
        }
        return $conn;
    }
    }

?>

